# BINAM NISHON — Website
Initial GitHub Pages build for the BINAM NISHON project.

## Upload
Upload `index.html` to the repository:
`binamnishonking.github.io`

Then enable GitHub Pages from Settings → Pages → Deploy from branch → main → / (root).

This is the first working visual build; content and sections can be expanded in later iterations.
